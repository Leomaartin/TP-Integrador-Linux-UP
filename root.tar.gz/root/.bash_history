history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
sudo apt update
sudo apt update
sudo vi /etc/hosts
sudo ls
sudo vi /etc/resolv.conf
sudo apt update
sudo apt update
ping -c 4 8.8.8.8
sudo systemctl restart networking
sudo dhclient -v
sudo dhclient -v enp0s3
sudo apt update
sudo vi /etc/resolv.conf
ping -c 4 8.8.8.8
cat /etc/resolv.conf
sudo vi /etc/resolv.conf
sudo vi /etc/resolv.conf
cat /etc/resolv.conf
sudo apt update
sudo apt -o Acquire::ForceIPv4=true update
sudo systemctl restart networking
sudo apt update
sudo host debian.org 8.8.8.8
sudo apt update
ip a
hostname -I
cat > /etc/apt/sources.list << EOF
deb http://deb.debian.org/debian bullseye main contrib non-free

cat > /etc/apt/sources.list
apt update
echo "nameserver 8.8.8.8" > /etc/resolv.conf
ping google.com
ping 8.8.8.8
dhClient
dhClient
dhclient
dhclient
apt update
apt upgrade -y
apt dist-upgrade -y
apt install openssh-server -y
systemctl status ssh
apt update
apt upgrade -y
apt dist-upgrade -y
cat /etc/debian_version
cat etc/apt//sources.list
cat /etc/apt//sources.list
cp /etc/apt/sources.list /etc/apt/sources.list.bak
nano /etc/apt/sources.list
sed -i 's/bullseye/bookworm/g'
vi /etc/sources.list
vi /etc/apt/sources.list
vi /etc/apt/sources.list
vi /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt install nano -y
nano /etc/apt/sources.list
apt update
apt full-upgrade -y
reboot
ip a
ip route
cp /etc/network/interfaces /etc/network/interfaces.bak
nano /etc/network/interfaces
systemctl restart networking
reboot
ip a
poweroff
fdisk -l
fdisk /dev/sdc
fdisk /dev/sdc
fdisk /dev/sdc
mkfs.ext4 /dev/sdc1
