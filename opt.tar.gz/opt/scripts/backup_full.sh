#!/bin/bash

if [ "$1" = "-help" ]; then
     echo "Uso: backup_full.sh <origen> <destino>"
     echo "Ejemplo:"
     echo "backup_full.sh /var/log /backup_dir"
     exit 0
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ]; then
      echo "Origen no existe"
      exit 1
fi
if [ ! -d "$DESTINO" ]; then
      echo "Destino no existe"
      exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")

tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"
